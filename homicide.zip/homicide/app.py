#import the necessary libraries
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from streamlit_option_menu import option_menu
from PIL import Image
import plotly.express as px
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns


#Set page configuration
st.set_page_config(page_title="Homicide Analysis", layout="wide")



# Load the data globally
@st.cache_data
def load_data():
    return pd.read_csv("homicide_data.csv", encoding="latin1")

# Load the data once
homicide_data = load_data()


def process_dataset(df):
    # 1. Ensure 'reported_date' is a string before replacing commas
    df['reported_date'] = df['reported_date'].astype(str).str.replace(",", "")
    
    # 2. Convert 'reported_date' to datetime format
    df['reported_date'] = pd.to_datetime(df['reported_date'], format='%Y%m%d', errors='coerce')
    
    # 3. Convert 'age' to numeric, replacing non-numeric entries with NaN
    df['victim_age'] = pd.to_numeric(df['victim_age'], errors='coerce')
    
    # 4. Calculate the mean age and fill NaN in the 'age' column
    mean_age = df['victim_age'].mean()
    df['victim_age'] = df['victim_age'].fillna(mean_age)
    
    # 5. Drop rows with any remaining NaN values
    df = df.dropna()

    return df


# Process a separate copy of the original dataset
homicide = process_dataset(homicide_data.copy())
# Remove the time series and keep only the date
homicide['reported_date'] = homicide['reported_date'].dt.date

# Extract years and months from the reported_date column

homicide['years'] = pd.to_datetime(homicide['reported_date'], errors='coerce').dt.year.astype(str).str.replace(",", "")


homicide['months'] = pd.to_datetime(homicide['reported_date'], errors='coerce').dt.strftime('%b')

# Group by year and count the occurrences
yearly_counts = homicide.groupby('years').size()

# Group by month and count the occurrences
monthly_counts = homicide.groupby('months').size()

# Ensure months are in the correct order
months_order = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
monthly_counts = monthly_counts[months_order]


# Categorize Victims by Age Distribution
def categorize_age(age):
    if pd.isna(age):  # Handle missing values
        return "Unknown"
    if 0 <= age <= 1:
        return "Infants"
    elif 1 < age <= 12:
        return "Children"
    elif 13 <= age <= 17:
        return "Teenagers"
    elif 18 <= age <= 65:
        return "Adults"
    elif age >= 66:
        return "Older Adults"
    else:
        return "Unknown"

# Create a new column for age distribution
homicide['Age Distribution'] = homicide['victim_age'].apply(categorize_age)

# Count victims by age category
age_counts = homicide['Age Distribution'].value_counts().reset_index()
age_counts.columns = ['Age Category', 'Victim Count']

# Race Distribution
# Count the occurrences of each unique value in the 'victim_race' column
race_counts = homicide['victim_race'].value_counts()



# Step 1: Group by race and disposition, and count occurrences (uid is the unique identifier)
case_disposition_race = homicide.groupby(['victim_race', 'disposition'])['uid'].count().reset_index(name='victim_count')





def main():
    with st.sidebar:
        selected = option_menu(
            menu_title="Main Menu",
            options=["Home", "Details",  "Data-Insights", "Exploratory Data Analysis", "Resources", "Feedback"],
            icons=["house", "chat-left-dots", "lightbulb-fill", "search", "book", 'phone'],
        )
    
    def show_welcome_page():
    #"Show the welcome page"
    # Displaying the image above the title
        header_image = Image.open("background.jpg")
        st.image(header_image, use_column_width=True)

    if selected == "Home":
        show_welcome_page()
        # Welcome message
        st.title("Homicide Cases in the United States")
        st.subheader("An Exploratory Analyis")
        st.write("Please select an option by the navigation tab to get started.")
    
    elif selected == "Details":
        st.info(
            """
            Homicide, a term that carries a heavy weight, echoes through the annals of human history, 
            revealing both the darkest aspects of our society and the ceaseless pursuit of justice. 
            This project explores a data-driven journey into the realm of criminal homicides across the vast landscape of the United States. 
            Through the lens of statistics, we aim to shed light on the patterns, trends, and underlying factors that shape this tragic phenomenon.
        """
        )
        st.image("homicide-unsplashed.jpg")

    elif selected == "Data-Insights":
        
        tab1, tab2, tab3 = st.tabs(["Dataset Overview", "Explore Dataset", "Cleaned Dataset"])
        
        with tab1:
            st.subheader("Dataset Overview")
            st.dataframe(homicide_data)
            st.write(homicide_data.shape)

            st.info(
    """
    The dataset utilized in this project was downloaded from Kaggle, obtained from The Washington Post. 
    The dataset contains comprehensive information on homicide cases reported in various cities in the United States. 
    It covers a period spanning from 2007 to 2017. This time frame allows for an extensive examination of homicidal cases 
    in selected 50 US cities over several years, providing a robust basis for analysis and insights into trends and patterns over time. 
    To access the dataset, [click here](https://www.kaggle.com/datasets/joebeachcapital/homicides).
    """
)
        with tab2:
        
            # Display the count of missing values for each column
            st.subheader("Checking some details of the dataset")
            st.write("Missing values in each column:")
            st.dataframe(homicide_data.isnull().sum().reset_index().rename(columns={0: 'Missing Values', 'index': 'Column'}))

            st.write("data types")
            st.write(homicide_data.dtypes)
        
        with tab3:
            
            st.subheader("Homicide Dataset with Age Missing Values Filled with Mean")
            st.dataframe(homicide)



    elif selected == "Exploratory Data Analysis":
        tab1, tab2, tab3, tab4 = st.tabs(["Victims' Demographics", "Geographic Pattern", "Trends over Years", "Disposition Analysis"])

        with tab1:
            st.subheader(" 1. Age Distribution")
            fig = px.bar(
            age_counts,
            x='Age Category',
            y='Victim Count',
            title="Count of Victims by Age Category",
            labels={'Victim Count': 'Count', 'Age Category': 'Age Category'},
            text='Victim Count'
            )
            fig.update_traces(textposition='outside')
            st.plotly_chart(fig, use_container_width=True)

            # Display pie chart for sex of victims (Male, Female, Unknown)
            st.subheader("2. Gender Breakdown")
            sex_counts = homicide['victim_sex'].value_counts().reindex(['Male', 'Female', 'Unknown'], fill_value=0)
        
            # Plot pie chart
            fig_sex = px.pie(
                sex_counts,
                names=sex_counts.index,
                values=sex_counts.values,
                title="Victim Sex Distribution",
                labels={'value': 'Count', 'names': 'Sex'},
            )
            st.plotly_chart(fig_sex, use_container_width=True)

            # Display pie chart for race of victims ()
            st.subheader("3. Race and Ethnicity")
            fig_race = plt.figure(figsize=(10, 6))
            race_counts.plot(kind='bar', color='salmon')
            
            plt.xlabel('Race', fontsize=14)
            plt.ylabel('Count', fontsize=14)
            plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
            plt.tight_layout()
            st.pyplot(fig_race)

        with tab2:
            st.subheader("Top 10 Cities with Most Homicides")
            
            # Count the occurrences of homicides in each city
            city_counts = homicide_data["city"].value_counts()
            
            # Get the top 10 cities with the most homicides
            top_10_cities = city_counts.head(10)
            
            # Sort the values in descending order (highest first)
            top_10_cities = top_10_cities.sort_values(ascending=False)
            
            # Display the sorted bar chart
            st.bar_chart(top_10_cities)

        with tab3:
            # Plot the line graph for count over the years
            st.subheader(" 1. Temporal Patterns")
            fig1, ax1 = plt.subplots()
            ax1.plot(yearly_counts.index, yearly_counts.values, marker='o', color='b')
            ax1.set_title('Homicide Count Over the Years')
            ax1.set_xlabel('Year')
            ax1.set_ylabel('Homicide Count')
            st.pyplot(fig1)

            st.subheader(" 2. Seasonal Variation")
            # Plot the line graph for count over the months
            fig2, ax2 = plt.subplots()
            ax2.plot(monthly_counts.index, monthly_counts.values, marker='o', color='r')
            ax2.set_title('Homicide Count Over the Months')
            ax2.set_xlabel('Month')
            ax2.set_ylabel('Homicide Count')
            st.pyplot(fig2)

        with tab4:
            st.subheader("Homicide Map Visualization")
            
            # Step 2: Plot the double-stack bar chart
            fig = px.bar(
                case_disposition_race,
                x='victim_race',  # X-axis: Race
                y='victim_count',  # Y-axis: Count of homicides
                color='disposition',  # Different colors for each disposition
                title='Disposition of Homicide Cases by Race',
                labels={'victim_count': 'Count of Homicides', '_victim_race': 'Race', 'disposition': 'Case Disposition'},
                barmode='stack'  # This stacks the bars on top of each other
            )
            # Step 3: Show the chart in Streamlit
            st.plotly_chart(fig)


        #     image_col, title_col = st.columns((1,4))
        # #with image_col:
        #     #st.image('logo.png', width=180)
        # with title_col:
        #     st.title("ExploreAI Internship")
        #     st.subheader("Team 11")
        #     st.write('---')

        # st.info("Our data science and data engineer team, comprised of passionate and skilled professionals, excel in extracting insights from complex datasets. We prioritize innovation, collaboration, and excellence, actively engaging in professional development and adhering to strict data privacy protocols. Our team's commitment to excellence and collaborative spirit set us apart, consistently exceeding expectations.")
        # st.image("meet2.png")
    

    elif selected == "Resources":

        
        

        st.info(
            """
            The findings and insights from the exploration of this project have been documented publicly on Medium via this 
            [link](https://ezembaosinachi.medium.com/delving-into-homicides-in-the-united-states-a-data-driven-exploration-bb68b277f599). 
            In this article, I share visualizations, interesting patterns, valuable insights, limitations, 
            and citations that I discovered during the exploratory analysis
            """
        )
        st.image("book.jpg")
    

    
        

        # Feedback submission
    elif selected == "Feedback":
        st.subheader("Have you had a nice exploration, or a nice read? I would love to hear from you!")
        st.write("If you have any questions, suggestions, or feedback, feel free to reach out!")

        # Provide contact information
        st.write("You can contact me directly via email:")
        st.write("[ezembaosinachi64@gmail.com](mailto:ezembaosinachi64@gmail.com)")
        
        # Optional: Provide a message that you’re available for inquiries
        st.write("I look forward to hearing from you!")

        
            
            
            
            




# Required to let Streamlit instantiate our web app.
if __name__ == '__main__':
    main()
    